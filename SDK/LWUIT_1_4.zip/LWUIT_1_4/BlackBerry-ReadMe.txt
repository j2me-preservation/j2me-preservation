Follow the below instructions to use the Blackberry jars
--------------------------------------------------------

1) Download JDE's:
   4.6 - https://www.blackberry.com/Downloads/contactFormPreload.do?code=DC727151E5D55DDE1E950767CF861CA5&dl=3FC040AED3A9E7AD55ECAC2105F9C435
   4.7 - https://www.blackberry.com/Downloads/contactFormPreload.do?code=DC727151E5D55DDE1E950767CF861CA5&dl=4FDB8018F8E8F47E9ACC704C58CC4540

2) Download and Install the BB plugin - 
http://plugins.netbeans.org/PluginPortal/faces/PluginDetailPage.jsp?pluginid=11194

3) Integrate the BB emulators into NetBeans:

	3.1)Go to "Tools->Java Platforms"

	3.2)Choose "Add Platform..."

	3.3)Choose "Java ME MIDP Platform Emulator" and click "Next"

	3.4)Select the BB emulators and click "Next"

	3.5)Click "Finish"

4) Create a new "Java ME" project > "Mobile Application" and select the BB emulator as your "Emulator Platform"

5) Go to your project properties and under "Libraries & Resources" add the relevant BB jar file  

	5.1)For not touch use JDE 4.6 and "BlackberryPort.jar"

	5.2)For touch use JDE 4.7 and "BlackberryTouchPort.jar"


