/*
 * @(#)locale_md.h    1.0 00/11/22
 *
 * Copyright � 2003 Sun Microsystems, Inc. All rights reserved.
 * SUN PROPRIETARY/CONFIDENTIAL. Use is subject to license terms.
 */

#ifndef _LOCALE_MD_
#define _LOCALE_MD_

#include <locale.h>
#define SET_DEFAULT_LOCALE setlocale(LC_ALL,"")

#endif
